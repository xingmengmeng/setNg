(function($, doc,$$) {
	var obj;
	
	//请求数据
	askForData();
	
	function askForData(){
		mui.ajax('./js/data.json',{
			dataType:'json',//服务器返回json格式数据
			type:'get',//HTTP请求类型         
			success:function(e){
				//服务器返回响应，根据响应结果，分析是否登录成功；
				obj=e;
				//console.log(obj);
				$.ready(function() {
		
					//普通示例
					var userPicker = new $.PopPicker();
					//放入数据
					userPicker.setData(obj.data.datainfo.projectMenuData);
					var showUserPickerButton = doc.getElementById('showUserPicker');
					var userResult = doc.getElementById('userResult');
					showUserPickerButton.addEventListener('tap', function(event) {
						userPicker.show(function(items) {
							userResult.innerText =items[0].text;
							var globalValue=items[0].value;
							$$("#userResult").attr("data-value",globalValue);
							//console.log(globalValue)
							//返回 false 可以阻止选择框的关闭
							//return false;
							
							//渲染其余的列表项
							otherMenuData(globalValue);
							
						});
					}, false);	
				});
				
				//渲染列表初始数据
				initDataInfo();
				
				
				
			},
			error:function(xhr,type,errorThrown){
				//异常处理；
				console.log(type);
			}
		});
	}
	
	$.init();
	
	//渲染列表初始数据
	function initDataInfo(){
		
		var selfValue=$$("#userResult").data("value");//获取到zc等键名
		/*$.each(obj.data.datainfo.pageMenuData[selfValue],function(i,val){//遍历键名获取列表的名称
			val.text
		})*/
		
		//模拟的json对象
         var data = obj.data.datainfo.pageMenuData[selfValue];//console.log(data)
         
         //注册一个Handlebars模版，通过id找到某一个模版，获取模版的html框架
         var myTemplate = Handlebars.compile($$("#asideLisst").html());
         
         //将json对象用刚刚注册的Handlebars模版封装，得到最终的html，插入到基础table中。
         $$('#pageMenuList').html(myTemplate(data));
         
         //给列表项添加点击事件
		$$("#pageMenuList").on("tap","a",function(){
			var aHref=$$(this).attr("href");
			
			
			
		})
		
	}
	
	//点击确定后渲染其余的列表项
	function otherMenuData(globalValue){
		//模拟的json对象
        var data = obj.data.datainfo.pageMenuData[globalValue];//console.log(data)
         
        //注册一个Handlebars模版，通过id找到某一个模版，获取模版的html框架
        var myTemplate = Handlebars.compile($$("#asideLisst").html());
         
        //将json对象用刚刚注册的Handlebars模版封装，得到最终的html，插入到基础table中。
        $$('#pageMenuList').html(myTemplate(data));
    
	}

	function addAsideMenuEvent(){
		$$("#pageMenuList").on("click","a",function(){
			/*var aHref=$(this).attr("href");
			console.log(aHref)*/
			alert(1)
		})
		
	}
	
})(mui, document, jQuery);