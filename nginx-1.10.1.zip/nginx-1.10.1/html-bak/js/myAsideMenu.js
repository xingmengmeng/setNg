(function($,doc,appGlobal){
	/*
 	 * 侧边栏菜单
 	 */
 	var asideMenu={
 		//渠道菜单数据
 		projectMenuData:null,
 		//页面菜单数据
 		pageMenuData:null,
		textDom:null,
 		//当前渠道菜单以及页面菜单
 		current:{
 			project:'ol',
 			page:'ol-realtime'
 		},
		hisData:{
			project:'ol',
			page:'ol-realtime'
		},
 		tabMenus:[],		//缓存三级菜单数据
 		curPageCls:'ph-menu-current',	//当前菜单class
 		//配置信息
 		config:{
 			pageWrapper:$('#pageWrapper'),
 			pageMenuListId:'pageMenuList',
 			menuToggleId:'menuToggle',
 			opacityBgId:'phOpacityBg',
 			menuKeyName:'node-key',
 			goToChangeLogId:"goToChangeLog",		//前往版本升级页面按钮id
 			changeLogUrl:'/changelog.cl',			//url
 			descriptionToggleId:'descToggle',		//指标说明按钮
 			descriptionUrl:'/description.cl',		//地址
 			descKey:'pagekey',						//传递参数key
 			pageTitleDom:$('header .mui-title')		//页面titile dom
 		},
 		init:function(projectKey,pageKey,subnav){
 			this.current={
 				project:projectKey,
 				page:pageKey
 			};
			this.hisData={
				project:projectKey,
				page:pageKey
			};
 			var self=this;
 			appGlobal.util.ajaxGetData('/getUserPowerAll.cl','datainfo',function(menudata){
 				//设置显示页面名称
 				self.config.pageTitleDom[0].innerHTML=[self.findValueByKey(menudata.projectMenuData,'value',self.current.project,'text'),
 					'-',
 					self.findValueByKey(menudata.pageMenuData[self.current.project],'key',self.current.page,'text')].join('');
 				
 				self.projectMenuData=menudata.projectMenuData;
 				self.pageMenuData=menudata.pageMenuData;
 				
 				self.initProjectPicker();
	 			self.createPageMenuDom();
	 			self.getTabMenusData();
	 			self.bindEvents();
				self.bindDescription(subnav);
 			});
 		},
 		//初始化渠道切换选择
 		initProjectPicker:function(){
			var self=this;
			self.initProject();
			self.togglePicker();
 		},
		initProject:function(){
			var projPicker = new $.PopPicker(),self=this;
			projPicker.setData(this.projectMenuData);
			var showUserPickerButton = doc.getElementById('ph-project-picker');
			var textDom=doc.querySelector('#ph-project-picker span');
			//初始化渠道菜单名称
			//self.togglePicker(self.projectMenuData,self.textDom);
			$.each(self.projectMenuData, function(i,menu) {
				if(menu.value==self.current.project){
					textDom.innerText = menu.text;
					return false;
				}
			});
		},
		togglePicker:function(projectMenuData,textDom){
			var projPicker = new $.PopPicker(),self=this;
			projPicker.setData(this.projectMenuData);
			var showUserPickerButton = doc.getElementById('ph-project-picker');
			showUserPickerButton.addEventListener('tap', function(event) {
				projPicker.show(function(items) {
					if(items[0].value==self.current.project) return true;
					self.current.project=items[0].value;
					self.initProject();
					self.createPageMenuDom();
					//返回 false 可以阻止选择框的关闭
					//		//return false;
				});
				//设置默认打开选中项
				projPicker.pickers[0].setSelectedValue(self.current.project,100);
			}, false);
		},
 		//创建页面菜单项
 		createPageMenuDom:function(){
 			var self=this,_temp=[];
 			$.each(self.pageMenuData[self.current.project], function(i,menu) {
 				_temp.push([
 					'<li class="mui-table-view-cell ',
 					menu.icon,
 					' ',
 					menu.key==self.current.page?self.curPageCls:'',
 					'">',
					'<a href="',
					menu.href,
					'" ',
					self.config.menuKeyName,
					'="',
					menu.key,
					'" class="mui-clearfix">',
						'<em></em>',
						'<span>',
						menu.text,	
						'</span>',
					'</a>',
					'</li>'
 				].join(''));

 			});
 			doc.getElementById(self.config.pageMenuListId).innerHTML=_temp.join('');
 		},
 		//绑定菜单打开及关闭事件
 		bindEvents:function(){
			var self=this;
			self.config.pageWrapper.on('tap','#'+self.config.menuToggleId,function(){
				self.current.project=self.hisData.project;
				self.current.page=self.hisData.page;
				self.initProject();
				self.createPageMenuDom();
				self.config.pageWrapper.offCanvas('show');
			});
			self.config.pageWrapper.on('tap','#'+self.config.opacityBgId,function(){
				self.config.pageWrapper.offCanvas('close');
			});
			//page菜单项点击事件
			$('#'+self.config.pageMenuListId).on('tap','a',function(){
				event.preventDefault();
				if(this.getAttribute(self.config.menuKeyName) == self.current.page) return false;
				$.openWindow({
					url:this.getAttribute('href')
				});
			});
			//前往版本升级
			self.config.pageWrapper.on('tap','#'+self.config.goToChangeLogId,function(){
				$.openWindow({
					url:self.config.changeLogUrl
				});
			});
 		},
		bindDescription:function(subnav){
			var self = this;
			//前往指标说明
			self.config.pageWrapper.on('tap','#'+self.config.descriptionToggleId,function(){
				$.openWindow({
					url:[self.config.descriptionUrl,'?',self.config.descKey,'=',self.current.page,subnav].join('')
				});
			});
		},
 		/*
 		 * 查找数组中指定对象的属性值
 		 * arr :待查找数组
 		 * key：查找key
 		 * value:key匹配值
 		 * reKey:返回该key的值
 		 */
 		findValueByKey:function(arr,key,value,reKey){
 			var re='';
 			$.each(arr, function(i,item) {
 				if(item[key] && item[key]==value){
 					re=item[reKey];
 				}
 			});
   			return re;
 		},
 		/*
 		 * 获取三级tab菜单数据
 		 */
 		getTabMenusData:function(){
 			var self=this;
 			$.each(this.pageMenuData[this.current.project], function(index,item) {
 				if(item.key==self.current.page){
 					self.tabMenus=item.children;
 					return;
 				}
 			});
 		}
 	};
 	appGlobal.asideMenu=asideMenu;
})(mui,document,biMobile=biMobile||{});