/*渠道分布*/
	// 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('qdfb'));
    
    // 图表加载动画
    // 指定图表的配置项和数据
	//myChart.showLoading();


	option = {
	    color: ['#3398DB'],
	    tooltip : {
	        trigger: 'axis',
	        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
	            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
	        }
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        top: '13%',
	        bottom: '8%',
	        containLabel: true
	    },
	    xAxis : [
	        {
	            //type : 'category',
	            data : ['应用市场','广告合作','SEM','大V推广','品专','自然'],//横轴的坐标
	            axisTick: {
	                alignWithLabel: true
	            },
	            axisLabel:{
	                 //X轴刻度配置
	                 interval:0 //0：表示全部显示不间隔；auto:表示自动根据刻度个数和宽度自动设置间隔个数
	            },
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    yAxis : [
	        {
	            type : 'value',
	            scale: true,
	            axisLabel: {
	            	formatter:'{value}w'
	            },
	            data: [''],
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    series : [
	        {
	            name:'直接访问',
	            type:'bar',
	            barWidth: '60%',
	            data:[10, 22, 30, 34, 50, 40]//传入具体的数值
	        }
	    ]
	};

    // 使用刚指定的配置项和数据显示图表。
  	myChart.setOption(option);
  	
/*客户端分布*/
  	// 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('khfb'));
    
    // 图表加载动画
    // 指定图表的配置项和数据
	//myChart.showLoading();


	option = {
	    color: ['#3398DB'],
	    tooltip : {
	        trigger: 'axis',
	        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
	            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
	        }
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        top: '13%',
	        bottom: '8%',
	        containLabel: true
	    },
	    xAxis : [
	        {
	            //type : 'category',
	            data : ['APP','H5','WEB','跨屏','其他'],//横轴的坐标
	            axisTick: {
	                alignWithLabel: true
	            },
	            axisLabel:{
	                 //X轴刻度配置
	                 interval:0 //0：表示全部显示不间隔；auto:表示自动根据刻度个数和宽度自动设置间隔个数
	            },
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    yAxis : [
	        {
	            type : 'value',
	            scale: true,
	            axisLabel: {
	            	formatter:'{value}w'
	            },
	            data: [''],
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    series : [
	        {
	            name:'直接访问',
	            type:'bar',
	            barWidth: '60%',
	            data:[30, 20, 10, 44, 50]//传入具体的数值
	        }
	    ]
	};

    // 使用刚指定的配置项和数据显示图表。
  	myChart.setOption(option);
  	
/*产品端分布*/
  	// 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('cpfb'));
    
    // 图表加载动画
    // 指定图表的配置项和数据
	//myChart.showLoading();


	option = {
	    color: ['#3398DB'],
	    tooltip : {
	        trigger: 'axis',
	        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
	            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
	        }
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        top: '13%',
	        bottom: '8%',
	        containLabel: true
	    },
	    xAxis : [
	        {
	            //type : 'category',
	            data : ['APP','H5','WEB','跨屏','其他'],//横轴的坐标
	            axisTick: {
	                alignWithLabel: true
	            },
	            axisLabel:{
	                 //X轴刻度配置
	                 interval:0 //0：表示全部显示不间隔；auto:表示自动根据刻度个数和宽度自动设置间隔个数
	            },
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    yAxis : [
	        {
	            type : 'value',
	            scale: true,
	            axisLabel: {
	            	formatter:'{value}w'
	            },
	            data: [''],
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    series : [
	        {
	            name:'直接访问',
	            type:'bar',
	            barWidth: '60%',
	            data:[30, 20, 10, 44, 50]//传入具体的数值
	        }
	    ]
	};

    // 使用刚指定的配置项和数据显示图表。
  	myChart.setOption(option);
  	
/*地域分布*/
  	// 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById('dyfb'));
    
    // 图表加载动画
    // 指定图表的配置项和数据
	//myChart.showLoading();


	option = {
	    color: ['#3398DB'],
	    tooltip : {
	        trigger: 'axis',
	        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
	            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
	        }
	    },
	    grid: {
	        left: '3%',
	        right: '4%',
	        top: '13%',
	        bottom: '8%',
	        containLabel: true
	    },
	    xAxis : [
	        {
	            //type : 'category',
	            data : ['APP','H5','WEB','跨屏','其他'],//横轴的坐标
	            axisTick: {
	                alignWithLabel: true
	            },
	            axisLabel:{
	                 //X轴刻度配置
	                 interval:0 //0：表示全部显示不间隔；auto:表示自动根据刻度个数和宽度自动设置间隔个数
	            },
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    yAxis : [
	        {
	            type : 'value',
	            scale: true,
	            axisLabel: {
	            	formatter:'{value}w'
	            },
	            data: [''],
	            splitLine:{ 
                	show:false
	            }
	        }
	    ],
	    series : [
	        {
	            name:'直接访问',
	            type:'bar',
	            barWidth: '60%',
	            data:[30, 20, 10, 44, 50]//传入具体的数值
	        }
	    ]
	};

    // 使用刚指定的配置项和数据显示图表。
  	myChart.setOption(option);